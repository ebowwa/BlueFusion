# Contributors

Thank you to all the contributors who have helped make BlueFusion better!

## Project Lead
- **ebowwa** - Creator and maintainer

## Contributors
<!-- Please add your name here when contributing -->

## How to Contribute

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details on how to get started.

### Ways to Contribute
- Report bugs and request features through GitHub Issues
- Submit pull requests with bug fixes or new features
- Improve documentation
- Help with testing and code reviews

## Recognition

All contributors will be added to this list. Thank you for your support!